<?php
header('location: controller/index.php');
?>