<?php 
  //khai báo đường dẫn 
  define("IMG_PATH_ADMIN","../view/layout/assets/images/");
  define("IMG_PATH_USER","view/layout/assets/images/");
?>