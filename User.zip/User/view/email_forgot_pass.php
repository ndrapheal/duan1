<body>
    <div class="container">
        <div style="display:flex; align-items: center ;justify-content:center;">
            <form class="bg-white" style="padding: 50px 100px; margin: 100px 0 150px 0; border-radius: 8px;" action="index.php?pg=forgot_password" method="post">
                <label class="nhap-code_title" for="Email">Nhập email:</label> <br>
                <input class="nhap-code_imput" type="email" placeholder="Email của bạn" name="Email_confirm" id="Email" style="height: 45px;
    width: 300px;
    padding: 0 10px;
    border: 2px solid #2b648b;
    border-radius: 8px;">
                <input class="nhap-code_btn btn-main" type="submit" name="Enter_email" value="Xác nhận">
            </form>
        </div>
    </div>