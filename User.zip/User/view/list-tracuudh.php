<br>
<br>
<div class="container d-flex align-items-center justify-content-center">
            <div class="order-chitiet_search__box">
                <h1>Tra cứu đơn hàng</h1>
                <!-- <?php echo $_GET['id_bill']; ?> -->
            <form action="index.php?pg=timkiem_bill" method="post">
                <input type="text" name="idbill" value="" placeholder="Nhập mã đơn hàng">
               
                <input type="submit" name="timkiem" value="Tìm kiếm" >
            </form>
            </div>
            
        </div>

        <br>
        <br>