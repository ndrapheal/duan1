<div class="card--container">
    <h3 class="main-title">Publisher Add</h3>
</div>
<hr>
<div class="main">
    <div class="table">
        <div class="table--header">
            <div class="containerr" id="productContainer">
                <form action="#" method="POST" enctype="multipart/form-data">
                    <!-- <div class="form-group">
                        <label for="id">Publisher ID:</label>
                        <input type="text" id="id" name="publisher_id" class="inputt" placeholder="Nhập ID" required>
                    </div> -->
                    <div class="form-group">
                        <label for="name">Publisher Name:</label>
                        <input type="text" id="name" name="name" class="inputt" placeholder="Tên nhà xuất bản" required>
                    </div>
                    <button type="submit" class="btn" name="btn_addPublisher">Done</button>
                    <button type="submit" class="btn" name="btnCancel">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>